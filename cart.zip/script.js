document.addEventListener("DOMContentLoaded", () => {
  loadProducts();
});
async function loadProducts() {
  try {
    const response = await fetch("http://localhost:5000/api/products");
    const data = await response.json();
    const container = document.getElementById("product-container");
    container.innerHTML = "";

    if (data.result && data.result.length > 0) {
      data.result.forEach(product => {
        const div = document.createElement("div");
        div.classList.add("product");
        div.innerHTML = `
        <a  href="product.html?id=${product.id}">
          <img src="${product.thumbnail_url}" alt="${product.name}" />
          <h3>${product.name}</h3>
          <p>${product.variants[0]?.retail_price || 'Price not available'} CHF</p>
          </a>
        `;
        container.appendChild(div);
      });
    } else {
      container.innerHTML = "<p>No products found.</p>";
    }
  } catch (error) {
    console.error("Error loading products:", error);
    const container = document.getElementById("product-container");
    container.innerHTML = "<p style='color:red;'>Failed to load products.</p>";
  }
  function viewProduct(productId) {
    alert("Feature coming soon for product ID: " + productId);
  }
  document.getElementById("product-name").textContent = product.name;
  document.getElementById("product-img").scr = product.thumbnail_url;
  document.getElementById("product-price").textContent = "25"; // or use product.variants[0].retail_price
}

fetch('http://localhost:5000/api/products')
  .then(response => response.json())
  .then(data => {
    console.log('Products from API:', data);

    const productList = document.getElementById('product-list');
    if (!productList) return;

    data.result.forEach(product => {
      const item = document.createElement('div');
      item.innerHTML = `
        <h3>${product.name}</h3>
        <img src="${product.thumbnail_url}" alt="${product.name}" width="150">
        <p>Variants: ${product.variants}</p>
      `;
      productList.appendChild(item);
    });
  })
  .catch(error => {
    console.error('Error fetching products:', error);
  });
