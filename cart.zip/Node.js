// Node.js or server.js
const express = require("express");
const app = express();
const cors = require("cors");

app.use(cors());
app.use(express.static("public")); // optional
app.use(express.json());

const products = [
  { id: 1, name: "Shirt", price: 19.99 },
  { id: 2, name: "Pants", price: 29.99 },
];

app.get("/products", (req, res) => {
  res.json(products);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
